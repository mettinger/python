
Code dependencies:

the Anaconda distribution of Python has all the packages required.

Running code for Question #1:

Change the line "dataFile = ..." to the correct local path to the data.

$ python dataExplore.py

Running code for Question #2:

Change the line "dataFile = ..." to the correct local path to the data.

$ python classifyLoans.py

Running code for Question #3:

$ python dataDownload.py https://resources.lendingclub.com/LoanStats3b.csv.zip 1000
